from django.db import models

# Create your models here.
class Cyberbulling(models.Model):
    c_id = models.AutoField(primary_key=True)
    comment = models.CharField(max_length=1000)
    date = models.DateField()
    time = models.TimeField()

    class Meta:
        # managed = False
        db_table = 'cyberbulling'

