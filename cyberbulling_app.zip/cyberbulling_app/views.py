from django.shortcuts import render
from cyberbulling.models import Cyberbulling

# Create your views here.
def add(request):
    if request.method=="POST":
        obj=Cyberbulling()
        obj.comment=request.POST.get('name')
        obj.date=request.POST.get('date')
        obj.time=request.POST.get('time')
        obj.save()
    return render(request,'cyberbulling/add_bulling.html')





def view(request):
    ob=Cyberbulling.objects.all()
    context={
        'objval':ob
    }
    return render(request,'cyberbulling/view_bulling.html',context)


def admin_view(request):
    ob=Cyberbulling.objects.all()
    context={
        'objval':ob
    }
    return render(request,'cyberbulling/view_admin.html',context)
