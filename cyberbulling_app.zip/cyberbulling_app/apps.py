from django.apps import AppConfig


class CyberbullingConfig(AppConfig):
    name = 'cyberbulling'
