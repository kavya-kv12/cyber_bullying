from django.conf.urls import url
from cyberbulling import views


urlpatterns =[
    url('cyber/', views.add),
    url('view/', views.view),
    url('ad/',views.admin_view)
]